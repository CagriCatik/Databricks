# Databricks notebook source
# MAGIC %md-sandbox
# MAGIC
# MAGIC <div  style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://raw.githubusercontent.com/derar-alhussein/Databricks-Certified-Data-Engineer-Associate/main/Includes/images/bookstore_schema.png" alt="Databricks Learning" style="width: 600">
# MAGIC </div>

# COMMAND ----------

# MAGIC %run ../Includes/Copy-Datasets

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Reading Stream

# COMMAND ----------

(spark.readStream
      .table("books")
      .createOrReplaceTempView("books_streaming_tmp_vw")
)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Displaying Streaming Data

# COMMAND ----------

books_streaming_df = spark.sql("SELECT * FROM books_streaming_tmp_vw")
display(books_streaming_df, checkpointLocation = f"{checkpoints_bookstore}/tmp/books_streaming_{time.time()}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Applying Transformations

# COMMAND ----------

author_counts_df = spark.sql("""SELECT author, count(book_id) AS total_books
                                  FROM books_streaming_tmp_vw
                                  GROUP BY author""")
display(author_counts_df, checkpointLocation = f"{checkpoints_bookstore}/tmp/author_counts_{time.time()}")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Unsupported Operations

# COMMAND ----------

sorted_books_df = books_streaming_df.orderBy("author")

(sorted_books_df.writeStream
                .option("checkpointLocation", f"{checkpoints_bookstore}/sorted_books")
                .trigger(availableNow=True)
                .format("console")
                .start()
)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Persisting Streaming Data

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW author_counts_tmp_vw AS (
# MAGIC   SELECT author, count(book_id) AS total_books
# MAGIC   FROM books_streaming_tmp_vw
# MAGIC   GROUP BY author
# MAGIC )

# COMMAND ----------

# Trigger type ProcessingTime is not supported for Serverless compute.
# (See: https://docs.databricks.com/aws/en/compute/serverless/limitations#streaming-limitations)
# Recommended Solution: Use Delta Live Tables (DLT) pipelines (Lecture 31) with Continuous mode.
# Alternative Workaround: use trigger AvailableNow

#(spark.table("author_counts_tmp_vw")                               
#      .writeStream  
#      .trigger(processingTime='4 seconds')
#      .outputMode("complete")
#      .option("checkpointLocation", f"{checkpoints_bookstore}/author_counts")
#      .table("author_counts")
#)

# COMMAND ----------

# MAGIC %sql
# MAGIC --SELECT *
# MAGIC --FROM author_counts

# COMMAND ----------

# MAGIC %md
# MAGIC ## Adding New Data

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO books (book_id, title, author, category, price)
# MAGIC values ("B19", "Introduction to Modeling and Simulation", "Mark W. Spong", "Computer Science", 25),
# MAGIC         ("B20", "Robot Modeling and Control", "Mark W. Spong", "Computer Science", 30),
# MAGIC         ("B21", "Turing's Vision: The Birth of Computer Science", "Chris Bernhardt", "Computer Science", 35)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Streaming in Batch Mode 

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO books (book_id, title, author, category, price)
# MAGIC values ("B16", "Hands-On Deep Learning Algorithms with Python", "Sudharsan Ravichandiran", "Computer Science", 25),
# MAGIC         ("B17", "Neural Network Methods in Natural Language Processing", "Yoav Goldberg", "Computer Science", 30),
# MAGIC         ("B18", "Understanding digital signal processing", "Richard Lyons", "Computer Science", 35)

# COMMAND ----------

(spark.table("author_counts_tmp_vw")                               
      .writeStream           
      .trigger(availableNow=True)
      .outputMode("complete")
      .option("checkpointLocation", f"{checkpoints_bookstore}/author_counts")
      .table("author_counts")
      .awaitTermination()
)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM author_counts
