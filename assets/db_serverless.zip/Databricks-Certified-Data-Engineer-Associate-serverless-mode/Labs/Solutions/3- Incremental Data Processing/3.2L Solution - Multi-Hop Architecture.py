# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC ## Lab Solution: Multi-Hop Architecture

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC <div  style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://raw.githubusercontent.com/derar-alhussein/Databricks-Certified-Data-Engineer-Associate/main/Labs/Includes/images/school_schema.png" alt="School Schema" style="width: 600">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC Run the following cell to setup the lab environment

# COMMAND ----------

# MAGIC %run ../Includes/Setup-Lab

# COMMAND ----------

# MAGIC %md
# MAGIC In this lab, you are going to build a medallion architecture in **incremental triggered mode**.

# COMMAND ----------

# MAGIC %md
# MAGIC #### Q1- Declaring Bronze Table
# MAGIC
# MAGIC Use Auto Loader to incrementally load enrollments json files from the directory **{dataset_school}/enrollments-json-raw** to a Delta table called **`bronze`**
# MAGIC

# COMMAND ----------

def process_bronze():
  dataset_source = f"{dataset_school}/enrollments-json-raw"
  bronze_checkpoint_path = f"{checkpoints_school}/bronze"
  schema_location = bronze_checkpoint_path

  # ANSWER
  (spark.readStream
          .format("cloudFiles")
          .option("cloudFiles.format", "json")
          .option("cloudFiles.schemaLocation", schema_location)
          .load(dataset_source)
        .writeStream
          .option("checkpointLocation", bronze_checkpoint_path)
          .outputMode("append")
          .trigger(availableNow=True)
          .table("bronze")
          .awaitTermination()
  )

process_bronze()

# COMMAND ----------

# MAGIC %md
# MAGIC Let's create a streaming temporary view from the bronze table in order to perform transformations using SQL.

# COMMAND ----------

(spark
  .readStream
  .table("bronze")
  .createOrReplaceTempView("bronze_tmp"))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Q2 - Data Cleansing & Enrichment
# MAGIC
# MAGIC Using CTAS syntax, define a new streaming view **`bronze_cleaned_tmp`** against **`bronze_tmp`** that does the following:
# MAGIC * Remove records with **quantity** of 0 item
# MAGIC * Add a column called **`processing_time`** containing the current timestamp using the **current_timestamp()** function

# COMMAND ----------

# MAGIC %sql
# MAGIC -- ANSWER
# MAGIC CREATE OR REPLACE TEMPORARY VIEW bronze_cleaned_tmp AS
# MAGIC SELECT
# MAGIC   *, current_timestamp() processing_time
# MAGIC   FROM bronze_tmp
# MAGIC   WHERE quantity > 0

# COMMAND ----------

# MAGIC %md
# MAGIC #### Q3 - Declaring Silver Table
# MAGIC
# MAGIC Stream the data from **`bronze_cleaned_tmp`** to a table called **`silver`**.

# COMMAND ----------

def process_silver():
  silver_checkpoint_path = f"{checkpoints_school}/silver"

  # ANSWER
  (spark.table("bronze_cleaned_tmp")
                .writeStream
                .option("checkpointLocation", silver_checkpoint_path)
                .outputMode("append")
                .trigger(availableNow=True)
                .table("silver")
                .awaitTermination()
  )

process_silver()

# COMMAND ----------

# MAGIC %md
# MAGIC Let's create a streaming temporary view from the silver table in order to perform business-level aggregation using SQL

# COMMAND ----------

(spark
  .readStream
  .table("silver")
  .createOrReplaceTempView("silver_tmp"))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Q4- Declaring Gold Table
# MAGIC
# MAGIC Using CTAS syntax, define a new streaming view **`enrollments_per_student_tmp_vw`** against **`silver_tmp`** to count the number of enrollments per **`student`**. Name the aggregated field: **`enrollments_count`**

# COMMAND ----------

# MAGIC %sql
# MAGIC -- ANSWER
# MAGIC CREATE OR REPLACE TEMPORARY VIEW enrollments_per_student_tmp_vw AS
# MAGIC SELECT
# MAGIC   student_id, count(enroll_id) AS enrollments_count
# MAGIC   FROM silver_tmp
# MAGIC   GROUP BY student_id

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Stream the aggregated data from the **`enrollments_per_student_tmp_vw`** view to a Delta table called **`gold_enrollments_stats`**.

# COMMAND ----------

def process_gold():
  gold_checkpoint_path = f"{checkpoints_school}/gold_enrollments_stats"

  # ANSWER
  query = (spark.table("enrollments_per_student_tmp_vw")
                .writeStream
                .option("checkpointLocation", gold_checkpoint_path)
                .outputMode("complete")
                .trigger(availableNow=True)
                .table("gold_enrollments_stats")
                )
  
  query.awaitTermination()

process_gold()

# COMMAND ----------

# MAGIC %md
# MAGIC Query the data in the **`gold_enrollments_stats`** table to ensure data was written as expected.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM gold_enrollments_stats

# COMMAND ----------

# MAGIC %md
# MAGIC Run the below cell to land new a json file of enrollments data, and reprocess it through all pipeline layers

# COMMAND ----------

load_new_json_data()

process_bronze()
process_silver()
process_gold()

# COMMAND ----------

# MAGIC %md
# MAGIC Run the below query to verify that the statistics have been updated in the table **gold_enrollments_stats**

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM gold_enrollments_stats
